package NumberGuessinggame;

import java.util.*;

public class numberGuessingGame {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		Random rand = new Random();
		
		int numberToGuess = rand.nextInt(100) + 1;
		int attempts = 0;
		int guess = 0 ;
		
		System.out.println("Welcome");
		System.out.println("I have picked a number between 1 and 100. try guess it!");
		
		while (guess != numberToGuess)
		{
			System.out.println("enter your guess: ");
			guess = sc.nextInt();
			attempts++;
			if (guess < numberToGuess)
			{
				System.out.println("To low! Try again");
			}
			else if(guess> numberToGuess)
			{
				System.out.println("to high Try again");
			}
			else {
				System.out.println("Correct you guess right in: "+ attempts + " attempts");
			}
		}
		sc.close();
	}

}
